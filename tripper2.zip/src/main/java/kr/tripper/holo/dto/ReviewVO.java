package kr.tripper.holo.dto;

public class ReviewVO {
	private int postno;
	private String email;
	private String repoto;
	private int rescore;
	private String retitle;
	private String recontent;
	private String retip;
	private String reperiod;
	private String retype;
	private String rewhy;
	public int getPostno() {
		return postno;
	}
	public void setPostno(int postno) {
		this.postno = postno;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getRepoto() {
		return repoto;
	}
	public void setRepoto(String repoto) {
		this.repoto = repoto;
	}
	public int getRescore() {
		return rescore;
	}
	public void setRescore(int rescore) {
		this.rescore = rescore;
	}
	public String getRetitle() {
		return retitle;
	}
	public void setRetitle(String retitle) {
		this.retitle = retitle;
	}
	public String getRecontent() {
		return recontent;
	}
	public void setRecontent(String recontent) {
		this.recontent = recontent;
	}
	public String getRetip() {
		return retip;
	}
	public void setRetip(String retip) {
		this.retip = retip;
	}
	public String getReperiod() {
		return reperiod;
	}
	public void setReperiod(String reperiod) {
		this.reperiod = reperiod;
	}
	public String getRetype() {
		return retype;
	}
	public void setRetype(String retype) {
		this.retype = retype;
	}
	public String getRewhy() {
		return rewhy;
	}
	public void setRewhy(String rewhy) {
		this.rewhy = rewhy;
	}
}
