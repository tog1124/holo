package kr.tripper.holo.dao;

import java.util.List;

import kr.tripper.holo.dto.PostVO;

public class PostDAOImpl implements PostDAO{

	@Override
	public List search(List code) {
		
		
		
		return null;
	}
	
}
