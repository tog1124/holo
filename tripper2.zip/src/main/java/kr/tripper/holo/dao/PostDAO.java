package kr.tripper.holo.dao;

import java.util.List;

import kr.tripper.holo.dto.PostVO;

public interface PostDAO {
	
	List search(List code);

}
