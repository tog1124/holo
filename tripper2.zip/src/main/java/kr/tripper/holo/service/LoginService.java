package kr.tripper.holo.service;

public interface LoginService {
	
	String signin(String email,String password);
	String signup(String email,String password);
	
}
